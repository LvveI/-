/*
Navicat MySQL Data Transfer

Source Server         : Mysql
Source Server Version : 80018
Source Host           : localhost:3306
Source Database       : chat

Target Server Type    : MYSQL
Target Server Version : 80018
File Encoding         : 65001

Date: 2019-12-24 15:29:44
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for chat_record
-- ----------------------------
DROP TABLE IF EXISTS `chat_record`;
CREATE TABLE `chat_record` (
  `id` varchar(50) NOT NULL,
  `message` text,
  `send_user` varchar(255) DEFAULT NULL,
  `receive_user` varchar(255) DEFAULT NULL,
  `is_read` varchar(5) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `group_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of chat_record
-- ----------------------------
INSERT INTO `chat_record` VALUES ('0bfd8d7f-89e6-4e80-bd2f-8f12d8442bc0', 'nimenhao', '李四', '1', '1', '2019-12-24 14:14:25', '111');
INSERT INTO `chat_record` VALUES ('2b4d6bcd-350e-45ea-8330-b89018c409b3', '哥？？', '范思辙', '1e9074bd-5368-4ac7-9fba-e14497476a20', '1', '2019-12-24 13:32:24', '111');
INSERT INTO `chat_record` VALUES ('333cf09e-1546-4ba9-80bc-e1a649b5a9ec', '123', '范闲', '1', '1', '2019-12-24 14:44:00', '111');
INSERT INTO `chat_record` VALUES ('60cd9b07-f7e6-494e-b734-11f90c439d77', '你们好', '范闲', '1', '1', '2019-12-24 13:29:34', '111');
INSERT INTO `chat_record` VALUES ('63390577-d895-4207-bbab-93390562a1a9', '在吗？', '范闲', '8391c073-c910-4ab7-91cf-cc872f21a023', '1', '2019-12-24 14:47:56', '111');
INSERT INTO `chat_record` VALUES ('8aab9b65-8d49-4fec-a0c6-c4323e372946', '在吗 范思辙', '范闲', '8391c073-c910-4ab7-91cf-cc872f21a023', '1', '2019-12-24 14:47:39', '111');
INSERT INTO `chat_record` VALUES ('91aa0fdc-5f69-4071-a5cc-f87dd52a51df', '你们好', '范闲', '1', '1', '2019-12-24 13:30:10', '111');
INSERT INTO `chat_record` VALUES ('9f91125c-e0d7-45a1-b6dd-4131e5191575', '<img src=\"arclist/74.gif\" border=\"0\" />', '范思辙', '1', '1', '2019-12-24 15:09:35', '111');
INSERT INTO `chat_record` VALUES ('e14aeef5-5837-4467-bb63-ef37eec68528', '哥', '范思辙', '1e9074bd-5368-4ac7-9fba-e14497476a20', '1', '2019-12-24 13:31:58', '111');

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user` (
  `userid` int(20) NOT NULL AUTO_INCREMENT,
  `id` varchar(50) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `is_online` varchar(5) DEFAULT NULL COMMENT '是否在线 0不在 1在线',
  `session_id` varchar(255) DEFAULT NULL COMMENT 'session_id',
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES ('1', '12313213123', 'zhangsan', '123', '2019-07-04 11:30:08', '张三', '0', null);
INSERT INTO `sys_user` VALUES ('2', 'b95ce225-579d-4318-b9cc-ff4406fe0ecb', 'lisi', '123', '2019-07-05 13:40:21', '李四', '0', null);
INSERT INTO `sys_user` VALUES ('8', '1e9074bd-5368-4ac7-9fba-e14497476a20', 'fx', '123', '2019-12-24 13:29:20', '范闲', '0', null);
INSERT INTO `sys_user` VALUES ('10', '8391c073-c910-4ab7-91cf-cc872f21a023', 'fsz', '123', '2019-12-24 13:31:25', '范思辙', '0', null);

-- ----------------------------
-- Table structure for sys_user_grp
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_grp`;
CREATE TABLE `sys_user_grp` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `userid` int(20) DEFAULT NULL,
  `grpid` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_user_grp
-- ----------------------------
INSERT INTO `sys_user_grp` VALUES ('4', '2', '1');
INSERT INTO `sys_user_grp` VALUES ('5', '2', '3');
INSERT INTO `sys_user_grp` VALUES ('6', '2', '4');
INSERT INTO `sys_user_grp` VALUES ('7', '2', '5');
INSERT INTO `sys_user_grp` VALUES ('8', '1', '2');
INSERT INTO `sys_user_grp` VALUES ('12', '10', '10');
INSERT INTO `sys_user_grp` VALUES ('13', '10', '8');
