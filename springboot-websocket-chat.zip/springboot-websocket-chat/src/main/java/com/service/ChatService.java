package com.service;

import com.model.ChatRecord;
/**
 * author：RhineDream
 */
public interface ChatService {

    int saveChatRecord(ChatRecord chatRecord);
}
