package com.service.impl;

import com.dao.UserDao;
import com.dao.UserGrpDao;
import com.model.User;
import com.model.UserGrp;
import com.service.UserGrpService;
import com.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
/**
 * author：RhineDream
 */
@Service
public class UserGrpServiceImpl implements UserGrpService {

    @Autowired
    private UserGrpDao userDao;
    

	@Override
	public void insert(UserGrp user) {
		userDao.insert(user);		
	}

	@Override
	public List<UserGrp> getUserList(int userid) {
		return userDao.getUserList(userid);
	}

	
	@Override
	public void detUser(int id) {
		userDao.detUser(id);
	}

	@Override
	public UserGrp getUser(int userid, int grpid) {
		return userDao.getUser(userid, grpid);
	}

   
}
