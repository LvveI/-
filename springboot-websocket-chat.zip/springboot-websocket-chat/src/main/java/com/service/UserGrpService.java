package com.service;

import com.model.User;
import com.model.UserGrp;

import java.util.List;

import org.apache.ibatis.annotations.Param;
/**
 * author：RhineDream
 */
public interface UserGrpService {
	
	  void insert(UserGrp user);
	  
	  void detUser(int id);

	  List<UserGrp> getUserList(int userid);
	  
	  UserGrp getUser(int userid, int grpid);
}
