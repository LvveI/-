package com.controller;

import com.model.ChatRecord;
import com.model.User;
import com.model.UserGrp;
import com.service.ChatService;
import com.service.UserGrpService;
import com.service.UserService;
import com.utils.ResponseResult;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

/**
 * author：RhineDream
 * 聊天controller
 */
@RestController
@RequestMapping("/user")
public class ChatController {

    @Autowired
    private UserService userService;
    @Autowired
    private UserGrpService userGrpService;

    /**
     * 获取用户列表
     * @param user
     * @return
     */
    @RequestMapping("/getUserList")
    public ResponseResult getUserList(@RequestBody(required = false) User user,HttpSession session){
    	 List<User> list =new ArrayList<User>();
    	 User userInfo = (User) session.getAttribute("userInfo");
    	 if(userInfo!=null) {
    	 List<UserGrp> userList = userGrpService.getUserList(userInfo.getUserid());
    	 if(userList.size()!=0){
	    	 for (UserGrp userGrp : userList) {
	    		 User user2 = userService.getUserById(userGrp.getGrpid());
	    		 list.add(user2);
			}
    	 }
    	}
        //List<User> list = userService.getUserList(user);
        return ResponseResult.ok(list);
    }
    
    /**
     * 获取用户列表
     * @param user
     * @return
     */
    @RequestMapping("/delUser")
    public String delUser(int userid,HttpSession session){
    	
    	 User userInfo = (User) session.getAttribute("userInfo");
    	 
    	 UserGrp user = userGrpService.getUser(userInfo.getUserid(), userid);
    	 userGrpService.detUser(user.getId());
    	 
    	 System.out.print(userid);
        return "200";
    }
    
    /**
     * 获取用户列表
     * @param user
     * @return
     */
    @RequestMapping("/addUser")
    public String addUser(String username,HttpSession session){
    	
    	 User userInfo = (User) session.getAttribute("userInfo");
    	 
    	 User user2 = userService.getUserByName(username);
    	 
    	 if(user2!=null&&userInfo!=null){
    		 
    		 UserGrp user1 = userGrpService.getUser(userInfo.getUserid(), user2.getUserid());
    		 if(user1!=null){
    			 return "她/他已经是你的好友了！不用添加"; 
    		 }else{
    			 UserGrp user =new UserGrp();
        		 user.setUserid(userInfo.getUserid());
        		 user.setGrpid(user2.getUserid());
        		 userGrpService.insert(user);
    		 }
    		 
    	 }else{
    		 return "该用户还没有注册"; 
    	 }
    	 
        return "添加好友成功";
    }

}
