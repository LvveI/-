package com.dao;

import com.model.User;
import com.model.UserGrp;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
/**
 * author：RhineDream
 */
@Mapper
public interface UserGrpDao {

   // User getUserByName(@Param("username") String username);

    void insert(UserGrp user);
    
    void detUser(@Param("id") int id);

    List<UserGrp> getUserList(int userid);
    
    UserGrp getUser(@Param("userid") int userid,@Param("grpid") int grpid);
}
